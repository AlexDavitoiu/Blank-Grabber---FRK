"""
package.nspkg.mod
"""
